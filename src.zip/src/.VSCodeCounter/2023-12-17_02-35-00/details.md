# Details

Date : 2023-12-17 02:35:00

Directory d:\\Documents\\Development\\vscode-counter\\src

Total : 10 files,  1218 codes, 96 comments, 80 blanks, all 1394 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Gitignore.ts](/Gitignore.ts) | TypeScript | 62 | 6 | 3 | 71 |
| [LineCounter.ts](/LineCounter.ts) | TypeScript | 138 | 7 | 3 | 148 |
| [LineCounterTable.ts](/LineCounterTable.ts) | TypeScript | 53 | 5 | 4 | 62 |
| [extension.ts](/extension.ts) | TypeScript | 750 | 35 | 43 | 828 |
| [internalDefinitions.ts](/internalDefinitions.ts) | TypeScript | 23 | 0 | 1 | 24 |
| [test/runTest.ts](/test/runTest.ts) | TypeScript | 13 | 5 | 5 | 23 |
| [test/suite/Gitignore.test.ts](/test/suite/Gitignore.test.ts) | TypeScript | 12 | 2 | 3 | 17 |
| [test/suite/extension.test.ts](/test/suite/extension.test.ts) | TypeScript | 9 | 3 | 3 | 15 |
| [test/suite/index.ts](/test/suite/index.ts) | TypeScript | 28 | 4 | 5 | 37 |
| [vscode-utils.ts](/vscode-utils.ts) | TypeScript | 130 | 29 | 10 | 169 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)