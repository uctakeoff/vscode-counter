# Summary

Date : 2023-12-17 02:35:00

Directory d:\\Documents\\Development\\vscode-counter\\src

Total : 10 files,  1218 codes, 96 comments, 80 blanks, all 1394 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 10 | 1,218 | 96 | 80 | 1,394 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 10 | 1,218 | 96 | 80 | 1,394 |
| . (Files) | 6 | 1,156 | 82 | 64 | 1,302 |
| test | 4 | 62 | 14 | 16 | 92 |
| test (Files) | 1 | 13 | 5 | 5 | 23 |
| test\\suite | 3 | 49 | 9 | 11 | 69 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)